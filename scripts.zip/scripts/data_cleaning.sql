-- Add a new column 'ride_length' that stores the duration of each ride
ALTER TABLE rides
ADD COLUMN ride_length INTERVAL;

-- Populate 'ride_length' with the duration between 'ended_at' and 'started_at'
UPDATE rides
SET ride_length = ended_at - started_at;

-- Add a new column 'day_of_week' to store the name of the day the ride started (e.g., Monday, Tuesday)
ALTER TABLE rides
ADD COLUMN day_of_week VARCHAR;

-- Populate 'day_of_week' based on the 'started_at' timestamp
UPDATE rides
SET day_of_week = TO_CHAR(started_at, 'Day');

-- Remove all rows with non-positive ride durations (i.e., 0 seconds or negative durations)
DELETE FROM rides
WHERE ride_length <= INTERVAL '0 seconds';