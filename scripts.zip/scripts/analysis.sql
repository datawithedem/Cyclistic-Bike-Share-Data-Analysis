-- 1. Overall Ride Statistics by Member Type
-- This query summarizes the total, average, maximum, and minimum ride lengths for members and casual riders.
SELECT
    member_casual,
    COUNT(ride_id) AS total_rides,
    AVG(ride_length) AS average_ride_length,
    MAX(ride_length) AS max_ride_length,
    MIN(ride_length) AS min_ride_length
FROM
    rides
GROUP BY
    member_casual;


-- 2. Ride Count and Average Ride Length by Day of the Week and Member Type
-- This query shows how riding behavior varies across days for both member types.
SELECT
    day_of_week,
    member_casual,
    COUNT(ride_id) AS total_rides,
    AVG(ride_length) AS average_ride_length
FROM
    rides
GROUP BY
    day_of_week, member_casual
ORDER BY
    day_of_week, member_casual;


-- 3. Ride Count and Average Ride Length by Hour of Day and Member Type
-- Analyzes what time of day rides are most frequent and how long they last for each user group.
SELECT
    EXTRACT(HOUR FROM started_at) AS hour_of_day, 
    member_casual,
    COUNT(ride_id) AS total_rides,
    AVG(ride_length) AS average_ride_length
FROM
    rides
GROUP BY
    hour_of_day, member_casual
ORDER BY
    hour_of_day, member_casual;


-- 4. Most Popular Start Stations by Member Type
-- Identifies the top 20 most frequently used start stations by member category.
SELECT
    start_station_name,
    member_casual,
    COUNT(ride_id) AS total_rides
FROM
    rides
WHERE
    start_station_name IS NOT NULL
GROUP BY
    start_station_name, member_casual
ORDER BY
    total_rides DESC
LIMIT 20;


-- 5. Distribution of Ride Lengths by Member Type
-- Categorizes ride lengths into buckets and counts how many fall into each range for each user type.
SELECT
    CASE
        WHEN ride_length <= INTERVAL '15 minutes' THEN '0-15 min'
        WHEN ride_length <= INTERVAL '30 minutes' THEN '15-30 min'
        WHEN ride_length <= INTERVAL '45 minutes' THEN '30-45 min'
        WHEN ride_length <= INTERVAL '60 minutes' THEN '45-60 min'
        ELSE '> 60 min'
    END AS ride_length_bucket,
    member_casual,
    COUNT(ride_id) AS total_rides
FROM
    rides
GROUP BY
    ride_length_bucket, member_casual
ORDER BY
    ride_length_bucket, member_casual;